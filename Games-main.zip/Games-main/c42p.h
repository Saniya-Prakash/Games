#ifndef C42P_H
#define C42P_H

void endtimer();
int win(char A[10][10], char c1, char c2);
void c42p();

#endif