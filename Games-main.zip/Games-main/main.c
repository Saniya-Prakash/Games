#include "rock_paper_scissor.h"
#include "tic_tac_toe_2p.h"
#include "c42p.h"
#include "tic_tac_toe_single.h"
#include <stdio.h>

int main() {
    c42p();
    return 0;
}
